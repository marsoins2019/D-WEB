<?php 
    $nomPage = "Inscrits";
    include("includes/header.php");  
    include("includes/content.php");
    include("includes/footer.php") 
?>