<?php 
    $nomPage = "Admin";
    include("includes/header.php");  
    include("includes/content.php");
    include("includes/footer.php") 
?>