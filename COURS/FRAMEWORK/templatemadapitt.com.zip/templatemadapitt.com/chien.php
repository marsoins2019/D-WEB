<?php
include("includes/header.php")
?>
 
 <div class="container my-5">

<!-- Section -->
<section>
  
  <style>
    .md-pills .nav-link.active {
      color: #fff;
      background-color: #616161;
    }
    button.close {
      position: absolute;
      right: 0;
      z-index: 2;
      padding-right: 1rem;
      padding-top: .6rem;
    }
  </style>
  
  <!-- Modal -->
      <div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
              <div class="modal-content">
                  <div class="modal-body p-0">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                      
                      <!-- Grid row -->
                      <div class="row">
                      
                          <!-- Grid column -->
                          <div class="col-md-6 py-5 pl-5">
                              
                              <h5 class="font-weight-normal mb-3">Description du chien</h5>

                             

                              <ul class="list-unstyled font-small mt-5">
                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Nom:</strong></p>
                                     
                                  </li>
                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Sex:</strong></p>
                                     
                                  </li>
                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Robe:</strong></p>
                                     
                                  </li>
                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Taille:</strong></p>
                                     
                                  </li>
                                  
                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Ossature:</strong></p>
                                      
                                  </li>

                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Age:</strong></p>
                                      
                                  </li>
                                  <li>
                                      <p class="text-uppercase mb-2"><strong>Numero de puce:</strong></p>
                                     
                                  </li>
                                  <li>
                                  <button type="button" class="btn btn-outline-success waves-effect">Contacter le Propriétaire</button>
                                  </li>
                              </ul>
                              
                          </div>
                          <!-- Grid column -->
                      
                          <!-- Grid column -->
                          <div class="col-md-6">
                              
                              <div class="view rounded-right">
                                  <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGan0yxSpyAI-WONGRPHOvV8mLLOXAtGpYAkIoe0kh1Dqn-2Bj&s" alt="Sample image">
                              </div>
                              
                          </div>
                          <!-- Grid column -->
                      
                      </div>
                      <!-- Grid row -->
                      
                  </div>
              </div>
          </div>
      </div>

  
  <h3 class="font-weight-bold text-center dark-grey-text pb-2">Les chiens</h3>
  <hr class="w-header my-4">
  <p class="lead text-center text-muted pt-2 mb-5">You can find several product design by our professional team in
    this section.</p>
      
  <!--First row-->
  <div class="row">

    <!--First column-->
    <div class="col-12">

      <!-- Nav tabs -->
      <ul class="nav md-pills flex-center flex-wrap mx-0" role="tablist">
        <li class="nav-item">
          <a class="nav-link active font-weight-bold text-uppercase" data-toggle="tab" href="#panel31" role="tab">Tous</a>
        </li>
        <li class="nav-item">
          <a class="nav-link font-weight-bold text-uppercase" data-toggle="tab" href="#panel32" role="tab">Male</a>
        </li>
        <li class="nav-item">
          <a class="nav-link font-weight-bold text-uppercase" data-toggle="tab" href="#panel33" role="tab">Femelle</a>
        </li>
      </ul>

    </div>
    <!--First column-->

  </div>
  <!--First row-->

  <!--Tab panels-->
  <div class="tab-content mb-5">

    <!--Panel 1-->
    <div class="tab-pane fade show in active" id="panel31" role="tabpanel">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-12 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://wallpaperaccess.com/full/1814445.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

              <h5 class="my-3">Nom:</h5>
            

            </div>

          </a>
          <!-- Card -->

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://www.itl.cat/pngfile/big/212-2122465_pit-bull-terrier-american-pitbull-wallpaper-dog-games.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src=" https://www.elsetge.cat/myimg/f/58-588815_pitbull-dog-wallpaper-hd-wallpapers-pitbull-dogs.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHigFm3OvNyYd1y2CBahBXLvaOr6cAepLs2KydiCJg_OiWXyPZ&s" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src=" https://images.unsplash.com/photo-1517982990603-1d52f060fe6a?ixlib=rb-1.2.1&w=1000&q=80" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">
            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://wallpaperset.com/w/full/0/a/e/175710.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!--Panel 1-->

    <!--Panel 2-->
    <div class="tab-pane fade" id="panel32" role="tabpanel">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-12 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://media.istockphoto.com/photos/beautiful-happy-pit-bull-dog-while-playing-in-the-park-picture-id1164366161?k=6&m=1164366161&s=612x612&w=0&h=8vkr7q_YXucGSqVbQBSJMomULBP34hAyLLIKv5oacvc=" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">
            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src=" https://i.pinimg.com/originals/94/c9/e7/94c9e740f8f8fcec4aa79865a7374353.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://i.pinimg.com/originals/c5/e0/91/c5e0917bd45805b344adf9269dd8c876.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!--Panel 2-->

    <!--Panel 3-->
    <div class="tab-pane fade" id="panel33" role="tabpanel">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-12 col-lg-4">

          <!-- Card -->
          <div class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://pbs.twimg.com/profile_images/487750950283534336/-VnJ1b4W.jpeg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </div>
          <!-- Card -->

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src="https://www.jakpost.travel/wimages/large/212-2121701_high-resolution-pitbull-dogs-wallpapers-174407-pitbull-dog.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">
            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-4">

          <!-- Card -->
          <a class="card hoverable mb-4" data-toggle="modal" data-target="#basicExampleModal">

            <!-- Card image -->
            <img class="card-img-top" src=" https://cameronscookware.com/wp-content/uploads/2019/12/pitbull-dog-wallpaper-fresh-american-pitbull-wallpapers-wallpaper-cave-for-you-of-pitbull-dog-wallpaper-1.jpg" alt="Card image cap">

            <!-- Card content -->
            <div class="card-body">

            <h5 class="my-3">Nom:</h5>
            </div>

          </a>
          <!-- Card -->

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!--Panel 3-->

  </div>
  <!--Tab panels-->

</section>
<!-- Section -->

</div>
 
 <?php
include("includes/footer.php")
?>