<?php
include("includes/h_admin.php")
?>

<h2 class="font-weight-bold text-center dark-text text-uppercase mb-4">Admin</h2>

<div class="container my-5 pt-5 pb-3 px-md-5 z-depth-1">


  <!--Section: Content-->
  <section class="dark-grey-text">

    <h3 class="text-center font-weight-bold mb-4 pb-2">Counter</h3>
    
    <h3 class="mb-3">Attributes</h3>
    
    <ul class="mb-4">
      <li>data-from : to change starting point</li>
      <li>data-to : to change ending point</li>
      <li>data-time : to change how long transition takes</li>
    </ul>

    <div class="count-up h1 text-center mb-4" data-from="10" data-to="20000" data-time="1000">
    	0
    </div>
    
    <h3 class="mb-3">
    	How long did you develop it? <span class="count1" data-from="0" data-to="5" data-time="2000">0</span> hours
    </h3>

  	<div>
    	Was it worth it? <span class="style"><span class="count2" data-from="0" data-to="100" data-time="1000">0</span> %</span>
    </div>

  	<div>
    	This many ppl trusted I can deliver it in one day <span class="count3 style" data-from="30" data-to="-30" data-time="5000"></span>
    </div>

  	<div class="pb-4">
    	It works with huge numbers too :O <span class="count4 style" data-from="-10000" data-to="10000" data-time="3000"></span>
  	</div>

  	<h3 class="my-4 block text-center">↓ Check this out ↓</h3>

  	<div class="mb-4">
    	You can animate it! <span class="pl-5 style last wow animated bounceIn delay-3s"><span class="count5" data-from="0" data-to="100" data-time="2000">0</span> %</span>
    </div>

  </section>
  <!--Section: Content-->


</div>





<div class="container my-5">

  
  <!-- Section: Block Content -->
  <section>
    
   
    <h3 class="font-weight-bold text-center dark-grey-text pb-2">Statistic Data</h3>
    <hr class="w-header my-4">
    <p class="lead text-center text-muted pt-2 mb-5">Lorem ipsum dolor sit amet consectetur adipisicing elit ex facere quas possimus.</p>

    <div class="row white-text">

      <!-- Grid column -->
      <div class="col-xl-3 col-md-6 mb-4">

        <!-- Card Primary -->
        <div class="card classic-admin-card primary-color">
          <div class="card-body py-3">
            <i class="far fa-money-bill-alt"></i>
            <p class="small">SALES</p>
            <h4>2000$</h4>
          </div>
          <div class="progress md-progress">
            <div class="progress-bar grey darken-3" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
          <div class="card-body pt-2 pb-3">
            <p class="small mb-0">Better than last week (25%)</p>
          </div>
        </div>
        <!-- Card Primary -->

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-xl-3 col-md-6 mb-4">

        <!-- Card Yellow -->
        <div class="card classic-admin-card warning-color">
          <div class="card-body py-3">
            <i class="fas fa-chart-line"></i>
            <p class="small">SUBSCRIPTIONS</p>
            <h4>200</h4>
          </div>
          <div class="progress md-progress">
            <div class="progress-bar bg grey darken-3" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
          <div class="card-body pt-2 pb-3">
            <p class="small mb-0">Worse than last week (25%)</p>
          </div>
        </div>
        <!-- Card Yellow -->

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-xl-3 col-md-6 mb-4">

        <!-- Card Blue -->
        <div class="card classic-admin-card light-blue lighten-1">
          <div class="card-body py-3">
            <i class="fas fa-chart-pie"></i>
            <p class="small">TRAFFIC</p>
            <h4>20000</h4>
          </div>
          <div class="progress md-progress">
            <div class="progress-bar grey darken-3" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
          <div class="card-body pt-2 pb-3">
            <p class="small mb-0">Better than last week (75%)</p>
          </div>
        </div>
        <!-- Card Blue -->

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-xl-3 col-md-6 mb-4">

        <!-- Card Red -->
        <div class="card classic-admin-card red accent-2">
          <div class="card-body py-3">
            <i class="fas fa-chart-bar"></i>
            <p class="small">ORGANIC TRAFFIC</p>
            <h4>2000</h4>
          </div>
          <div class="progress md-progress">
            <div class="progress-bar grey darken-3" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
          <div class="card-body pt-2 pb-3">
            <p class="small mb-0">Better than last week (25%)</p>
          </div>
        </div>
        <!-- Card Red -->

      </div>
      <!-- Grid column -->

    </div>

  </section>
  <!-- Section: Block Content -->
  

</div>




<?php
include("includes/f_admin.php")
?>
